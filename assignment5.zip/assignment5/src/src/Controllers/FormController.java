package src.Controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.swing.Timer;

import business.DummyTimer;
import business.OrdersBusinessInterface;
import database.OrderDataService;
import src.Models.User;


@ManagedBean
@ViewScoped
public class FormController {

	@Inject
	OrdersBusinessInterface service;
	
	
	
	public String onSubmit(User user) 
	{
		
		//Forward to Test Response View along with the USer Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "TestResponse.xhtml";
	}
	
	public OrdersBusinessInterface getService()
	{
		return service;
	}
	
	private void getAllOrders() {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:8888/ica5";
		String username = "root";
		String password = "root";
		String sql = "SELECT * FROM orders";
		
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println(String.format("ID is %d for Product %s at a price of 5f",
				rs.getInt("ID"),
				rs.getString("PRODUCT_NAME"),
				rs.getFloat("PRICE")));
			}
			rs.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally 
		{
			if(conn != null) {
				try
				{
					conn.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	private void insertAllOrders() {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:8888/ica5";
		String username = "root";
		String password = "root";
		String sql = "INSERT INTO ica5.orders(ORDER_NO, PRODUCT_NAME, PRICE, QUANTITY) VALUES ('001122334455', 'This was inserted new', 25.00, 100)";
		
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally 
		{
			if(conn != null) {
				try
				{
					conn.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}

}
