package src.Models;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Orders {
	
	List<Order> orders = new ArrayList<Order>();

	public Orders() {
		orders.add(new Order(1,"0000000000", "This is Product 1", 1.00f, 1));
		orders.add(new Order(2,"0000000001", "This is Product 2", (float)2.00, 2));
		orders.add(new Order(3,"0000000002", "This is Product 3", (float)3.00, 3));
		orders.add(new Order(4,"0000000003", "This is Product 4", (float)4.00, 4));
		orders.add(new Order(5,"0000000004", "This is Product 5", (float)5.00, 5));
		orders.add(new Order(6,"0000000005", "This is Product 6", (float)6.00, 6));
		orders.add(new Order(7,"0000000006", "This is Product 7", (float)7.00, 7));
		orders.add(new Order(8,"0000000007", "This is Product 8", (float)8.00, 8));
		orders.add(new Order(9,"0000000008", "This is Product 9", (float)9.00, 9));
		orders.add(new Order(10,"0000000009", "This is Product 10", (float)10.00, 10));
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
